print("Задание 1. Вывести несовпадающие строки из файлов.")
# Дано два текстовых файла. Выяснить, совпадают ли их строки. Если нет, то вывести несовпадающую строку
# из каждого файла.

with open(file='file1.txt', encoding='utf-8') as f1, open(file='file2.txt', encoding='utf-8') as f2:
    lines_f1 = f1.readlines(); lines_f2 = f2.readlines()
l1 = len(lines_f1); l2 = len(lines_f2); ml = max(l1, l2)  # подготовка к выравниванию длинны списков строк
if l1 != l2:  # если длины списков не равны добавляем в более короткий список None
    lines_f1[l1:ml] = [None] * (ml - l1); lines_f2[l2:ml] = [None] * (ml - l2)  # выравниваем длину списков
print(f"Списки несовпадающих строк в файлах:[{f1.name}, {f2.name}](None - строка с таким номером отсутствует)")
[print (f"№ строк {elm+1}:\n", [lines_f1[elm], lines_f2[elm]]) for elm in range(ml) if lines_f1[elm]!=lines_f2[elm]]

#====================================================================================================================
print("\nЗадание 2. Статистика по исходному файлу.")
# Дан текстовый файл. Необходимо создать новый файл и записать в него следующую статистику по исходному файлу:
# Количество символов; Количество строк; Количество гласных букв; Количество согласных букв; Количество цифр.

import re
with open(file='file3.txt', encoding='utf-8') as f1:
    content = f1.read()
count_newline = content.count("\n")
count_static = len(re.findall(r'(?i)[^аеёоиыуэюяaeiou_\W\d]+?', content))
count_digit = len(re.findall(r'\d+?', content))
content = f"Количество символов {len(content) - count_newline}\n" \
          f"Количество строк {count_newline + 1}\n" \
          f"Количество гласных букв {len(re.findall('(?i)[аеёоиыуэюяaeiou]+?', content))}\n" \
          f"Количество согласных букв {count_static}\n" \
          f"Количество цифр {count_digit}\n"
with open(file='file4.txt', mode="w", encoding='utf-8') as f2:
    f2.write(content)

#====================================================================================================================
print("\nЗадание 3. Дан текстовый файл. Удалить из него последнюю строку. Результат записать в другой файл.")

with open(file='file5.txt', mode="w", encoding='utf-8') as f1:
    f1.write("\n".join([str(elm) for elm in range(100, 110)]))
with open(file='file5.txt', mode="r", encoding='utf-8') as f1, open(file='file6.txt', mode="w", encoding='utf-8') as f2:
    f2.write("".join(f1.readlines()[:-1]))

#====================================================================================================================
print("Задание 4. Дан текстовый файл. Найти длину самой длинной строки.")
from random import randint
with open(file='file7.txt', mode="w") as f1:
    f1.write("\n".join([str(elm)*randint(10,70) for elm in range(0, 9)]))

with open(file='file7.txt') as f1:
    print(r"Длинна самой длинной строки c учетом символа разрыва строки \n:"
          f" {max(map(len, f1.readlines()))}")
    f1.seek(0)
    print(f"Длинна самой длинной строки без учета символа разрыва строки:"
          f" {max(map(lambda x:len(x.rstrip()), f1.readlines()))}")

#====================================================================================================================
print("\nЗадание 5 Дан текстовый файл. Посчитать сколько раз в нем встречается заданное пользователем слово.")
import re
search_word = input("Введите слово для поиска в тексте главы 17 из книги Р.Мартина \"Чистый код\": ")
with open(file='file8.txt',encoding='utf-8') as f1:
    print(f"Слово {search_word} встречается в тексте:",len(re.findall(rf"(?i)\b{search_word}\b", f1.read())),
          "раз. Производился поиск слова целиком без учета регистра(возможное вхождение в строку не учитывалось).")

#====================================================================================================================
print("\nЗадание 6. Дан текстовый файл. Найти и заменить в нем заданное слово. Что искать и на что заменять"
      " определяется пользователем.")
with open(file='file8.txt', encoding='utf-8') as f8, open(file='file9.txt', mode="w", encoding='utf-8') as f9:
    f9.write(f8.read())  # восстанавливаем оригинальный текст перед изменениями

old_word = input("Введите слово, которое хотите заменить в тексте главы 17 из книги Р.Мартина \"Чистый код\": ")
new_word = input(f"Введите слово, на которое хотите заменить слово \"{old_word}\": ")
with open(file='file9.txt', mode="r", encoding='utf-8') as f9:
    content = f9.read()
with open(file='file9.txt', mode="w", encoding='utf-8') as f9:
    f9.write(re.sub(rf'(?u)\b{old_word}\b', new_word, content))

print(f"Произведено", len(re.findall(rf'(?u)\b{old_word}\b', content)),
      "замен.\nЗаменены только полные совпадения слова. Поиск произведен с учетом регистра.")
